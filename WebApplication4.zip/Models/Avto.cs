﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication4.Models
{
    public class Avto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int dataVipuska { get; set; }

        public string opisanie { get; set; }
        public int price { get; set;}
    }
}